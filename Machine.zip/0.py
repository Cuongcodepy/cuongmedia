import os,sys,json
import time
import re

from requests import api
import requests
import threading
from threading import Thread
import six
import random
import datetime
from time import sleep
from pkg_resources import get_distribution, DistributionNotFound
import base64
import warnings
from six import *
from six.moves.urllib_parse import urljoin
from urllib.parse import unquote
SLEEP_EVERY_CHECK_FINISHED = 3
MAXIMUM_JOIN_TIME = 200


class Job(object):
    client = None
    task_id = None
    _last_result = None

    def __init__(self, client, task_id,time_sleep=2,typecaptcha=None):
        self.client = client
        self.task_id = task_id
        self.time_sleep=time_sleep
        self.typecaptcha=typecaptcha

    def _update(self):
        self._last_result = self.client.getTaskResult(self.task_id)

    def check_is_ready(self):
        self._update()
        if self._last_result['errorId'] !=0:
            return 2
        if self._last_result["status"] == "ready":
            return 1
        return 0

    def get_solution_response(self):  # Recaptcha
        if self._last_result['errorId'] !=0:
            return "ERROR|"+self._last_result['errorDescription']

        if self.typecaptcha=="funcaptcha":
            return self._last_result["solution"]["token"]
        if self.typecaptcha=="text":
            return self._last_result["solution"]["text"]
        return self._last_result["solution"]["gRecaptchaResponse"]

    def get_token_response(self):  # Funcaptcha
        return self._last_result["solution"]["token"]

    def get_answers(self):
        return self._last_result["solution"]["answers"]

    def get_captcha_text(self):  # Image
        return self._last_result["solution"]["text"]

    def get_cells_numbers(self):
        return self._last_result["solution"]["cellNumbers"]

    def report_incorrect(self):
        warnings.warn(
            "report_incorrect is deprecated, use report_incorrect_image instead",
            DeprecationWarning,
        )
        return self.client.reportIncorrectImage()

    def report_incorrect_image(self):
        return self.client.reportIncorrectImage(self.task_id)

    def report_incorrect_recaptcha(self):
        return self.client.reportIncorrectRecaptcha(self.task_id)

    def join(self, maximum_time=200):
        elapsed_time = 0
        maximum_time = maximum_time or MAXIMUM_JOIN_TIME

        while (True):

            time.sleep(self.time_sleep)
            sts= self.check_is_ready()

            if sts == 0:
                continue
            elif sts==1 :
                return
            else :
                return "ERROR"

            elapsed_time += SLEEP_EVERY_CHECK_FINISHED
            if elapsed_time is not None and elapsed_time > maximum_time:
                return "ERROR|TIMEOUT"

        while not self.check_is_ready():
            time.sleep(self.time_sleep)
            elapsed_time += SLEEP_EVERY_CHECK_FINISHED
            if elapsed_time is not None and elapsed_time > maximum_time:
                return "ERROR|TIMEOUT"


class AnycaptchaClient(object):
    client_key = None
    CREATE_TASK_URL = "/createTask"
    TASK_RESULT_URL = "/getTaskResult"
    BALANCE_URL = "/getBalance"
    REPORT_IMAGE_URL = "/reportIncorrectImageCaptcha"
    REPORT_RECAPTCHA_URL = "/reportIncorrectRecaptcha"
    APP_STAT_URL = "/getAppStats"
    SOFT_ID = 847
    language_pool = "en"
    response_timeout = 5

    def __init__(
        self, client_key, language_pool="en", host="api.anycaptcha.com", use_ssl=True
    ):
        self.client_key = client_key
        self.language_pool = language_pool
        self.base_url = "{proto}://{host}/".format(
            proto="https" if use_ssl else "http", host=host
        )
        self.session = requests.Session()

    @property
    def client_ip(self):
        if not hasattr(self, "_client_ip"):
            self._client_ip = self.session.get(
                "https://api.myip.com", timeout=self.response_timeout
            ).json()["ip"]
        return self._client_ip

    def _check_response(self, response):
        pass



    def createTask(self, task,typecaptcha=None):

        request = {
            "clientKey": self.client_key,
            "task": task.serialize(),
            "softId": self.SOFT_ID,
            "languagePool": self.language_pool,
        }
        response = self.session.post(
            urljoin(self.base_url, self.CREATE_TASK_URL),
            json=request,
            timeout=self.response_timeout,
        ).json()

        self._check_response(response)

        return Job(self, response["taskId"],time_sleep=task.time_sleep,typecaptcha=typecaptcha)

    def createTaskSmee(self, task, timeout=MAXIMUM_JOIN_TIME):
        """
        Beta method to stream response from smee.io
        """
        response = self.session.head(
            "https://smee.io/new", timeout=self.response_timeout
        )
        smee_url = response.headers["Location"]
        task = task.serialize()
        request = {
            "clientKey": self.client_key,
            "task": task,
            "softId": self.SOFT_ID,
            "languagePool": self.language_pool,
            "callbackUrl": smee_url,
        }
        r = self.session.get(
            url=smee_url,
            headers={"Accept": "text/event-stream"},
            stream=True,
            timeout=(self.response_timeout, timeout),
        )
        response = self.session.post(
            url=urljoin(self.base_url, self.CREATE_TASK_URL),
            json=request,
            timeout=self.response_timeout,
        ).json()
        self._check_response(response)
        for line in r.iter_lines():
            content = line.decode("utf-8")
            if '"host":"smee.io"' not in content:
                continue
            payload = json.loads(split(content, ":", 1)[1].strip())
            if "taskId" not in payload["body"] or str(payload["body"]["taskId"]) != str(
                response["taskId"]
            ):
                continue
            r.close()
            if task["type"] == "CustomCaptchaTask":
                payload["body"]["solution"] = payload["body"]["data"][0]
            job = Job(client=self, task_id=response["taskId"])
            job._last_result = payload["body"]
            return job

    def getTaskResult(self, task_id):
        request = {"clientKey": self.client_key, "taskId": task_id}
        response = self.session.post(
            urljoin(self.base_url, self.TASK_RESULT_URL), json=request
        ).json()
        self._check_response(response)
        return response

    def getBalance(self):
        request = {
            "clientKey": self.client_key,
            "softId": self.SOFT_ID,
        }
        response = self.session.post(
            urljoin(self.base_url, self.BALANCE_URL), json=request
        ).json()
        self._check_response(response)
        return response["balance"]

    def getAppStats(self, soft_id, mode):
        request = {"clientKey": self.client_key, "softId": soft_id, "mode": mode}
        response = self.session.post(
            urljoin(self.base_url, self.APP_STAT_URL), json=request
        ).json()
        self._check_response(response)
        return response

    def reportIncorrectImage(self, task_id):
        request = {"clientKey": self.client_key, "taskId": task_id}
        response = self.session.post(
            urljoin(self.base_url, self.REPORT_IMAGE_URL), json=request
        ).json()
        self._check_response(response)
        return response.get("status", False) != False

    def reportIncorrectRecaptcha(self, task_id):
        request = {"clientKey": self.client_key, "taskId": task_id}
        response = self.session.post(
            urljoin(self.base_url, self.REPORT_RECAPTCHA_URL), json=request
        ).json()
        self._check_response(response)
        return response["status"] == "success"
if six.PY3:

    def split(value, sep, maxsplit):
        return value.split(sep, maxsplit=maxsplit)


else:

    def split(value, sep, maxsplit):
        parts = value.split(sep)
        return parts[:maxsplit] + [
            sep.join(parts[maxsplit:]),
        ]
class AnycaptchaException(Exception):
    def __init__(self, error_id, error_code, error_description, *args):
        super(AnycaptchaException, self).__init__(
            "[{}:{}]{}".format(error_code, error_id, error_description)
        )
        self.error_description = error_description
        self.error_id = error_id
        self.error_code = error_code


AnticatpchaException = AnycaptchaException


class InvalidWidthException(AnycaptchaException):
    def __init__(self, width):
        self.width = width
        msg = "Invalid width (%s). Can be one of these: 100, 50, 33, 25." % (
            self.width,
        )
        super(InvalidWidthException, self).__init__("AC-1", 1, msg)


class MissingNameException(AnycaptchaException):
    def __init__(self, cls):
        self.cls = cls
        msg = 'Missing name data in {0}. Provide {0}.__init__(name="X") or {0}.serialize(name="X")'.format(
            str(self.cls)
        )
        super(MissingNameException, self).__init__("AC-2", 2, msg)
class BaseField(object):
    label = None
    labelHint = None

    def serialize(self, name=None):
        data = {}
        if self.label:
            data["label"] = self.label or False
        if self.labelHint:
            data["labelHint"] = self.labelHint or False
        return data


class NameBaseField(BaseField):
    name = None

    def serialize(self, name=None):
        data = super(NameBaseField, self).serialize(name)
        if name:
            data["name"] = name
        elif self.name:
            data["name"] = self.name
        else:
            raise MissingNameException(cls=self.__class__)
        return data


class SimpleText(BaseField):
    contentType = "text"

    def __init__(self, content, label=None, labelHint=None, width=None):
        self.label = label
        self.labelHint = labelHint

        self.content = content
        self.width = width

    def serialize(self, name=None):
        data = super(SimpleText, self).serialize(name)
        data["contentType"] = self.contentType
        data["content"] = self.content

        if self.width:
            if self.width not in [100, 50, 33, 25]:
                raise InvalidWidthException(self.width)
            data["inputOptions"] = {}
            data["width"] = self.width
        return data


class Image(BaseField):
    contentType = "image"

    def __init__(self, imageUrl, label=None, labelHint=None):
        self.label = label
        self.labelHint = labelHint
        self.imageUrl = imageUrl

    def serialize(self, name=None):
        data = super(Image, self).serialize(name)
        data["contentType"] = self.contentType
        data["content"] = self.imageUrl
        return data


class WebLink(BaseField):
    contentType = "link"

    def __init__(self, linkText, linkUrl, label=None, labelHint=None, width=None):
        self.label = label
        self.labelHint = labelHint

        self.linkText = linkText
        self.linkUrl = linkUrl

        self.width = width

    def serialize(self, name=None):
        data = super(WebLink, self).serialize(name)
        data["contentType"] = self.contentType

        if self.width:
            if self.width not in [100, 50, 33, 25]:
                raise InvalidWidthException(self.width)
            data["inputOptions"] = {}
            data["width"] = self.width

        data.update({"content": {"url": self.linkUrl, "text": self.linkText}})

        return data


class TextInput(NameBaseField):
    def __init__(self, placeHolder=None, label=None, labelHint=None, width=None):
        self.label = label
        self.labelHint = labelHint

        self.placeHolder = placeHolder

        self.width = width

    def serialize(self, name=None):
        data = super(TextInput, self).serialize(name)
        data["inputType"] = "text"

        data["inputOptions"] = {}

        if self.width:
            if self.width not in [100, 50, 33, 25]:
                raise InvalidWidthException(self.width)

            data["inputOptions"]["width"] = str(self.width)

        if self.placeHolder:
            data["inputOptions"]["placeHolder"] = self.placeHolder
        return data


class Textarea(NameBaseField):
    def __init__(
        self, placeHolder=None, rows=None, label=None, width=None, labelHint=None
    ):
        self.label = label
        self.labelHint = labelHint

        self.placeHolder = placeHolder
        self.rows = rows
        self.width = width

    def serialize(self, name=None):
        data = super(Textarea, self).serialize(name)
        data["inputType"] = "textarea"
        data["inputOptions"] = {}
        if self.rows:
            data["inputOptions"]["rows"] = str(self.rows)
        if self.placeHolder:
            data["inputOptions"]["placeHolder"] = self.placeHolder
        if self.width:
            data["inputOptions"]["width"] = str(self.width)
        return data


class Checkbox(NameBaseField):
    def __init__(self, text, label=None, labelHint=None):
        self.label = label
        self.labelHint = labelHint

        self.text = text

    def serialize(self, name=None):
        data = super(Checkbox, self).serialize(name)
        data["inputType"] = "checkbox"
        data["inputOptions"] = {"label": self.text}
        return data


class Select(NameBaseField):
    type = "select"

    def __init__(self, label=None, choices=None, labelHint=None):
        self.label = label
        self.labelHint = labelHint
        self.choices = choices or ()

    def get_choices(self):
        for choice in self.choices:
            if isinstance(choice, six.text_type):
                yield choice, choice
            else:
                yield choice

    def serialize(self, name=None):
        data = super(Select, self).serialize(name)
        data["inputType"] = self.type

        data["inputOptions"] = []
        for value, caption in self.get_choices():
            data["inputOptions"].append({"value": value, "caption": caption})

        return data


class Radio(Select):
    type = "radio"


class ImageUpload(NameBaseField):
    def __init__(self, label=None, labelHint=None):
        self.label = label
        self.labelHint = labelHint

    def serialize(self, name=None):
        data = super(ImageUpload, self).serialize(name)
        data["inputType"] = "imageUpload"
        return data
class BaseTask(object):
    def serialize(self, **result):
        return result


class ProxyMixin(BaseTask):
    def __init__(self, *args, **kwargs):
        self.proxyType = kwargs.pop("proxy_type")
        self.userAgent = kwargs.pop("user_agent")
        self.proxyAddress = kwargs.pop("proxy_address")
        self.proxyPort = kwargs.pop("proxy_port")
        self.proxyLogin = kwargs.pop("proxy_login")
        self.proxyPassword = kwargs.pop("proxy_password")

        self.cookies = kwargs.pop("cookies", "")
        super(ProxyMixin, self).__init__(*args, **kwargs)

    def serialize(self, **result):
        result = super(ProxyMixin, self).serialize(**result)
        result["userAgent"] = self.userAgent
        result["proxyType"] = self.proxyType
        result["proxyAddress"] = self.proxyAddress
        result["proxyPort"] = self.proxyPort
        if self.proxyLogin:
            result["proxyLogin"] = self.proxyLogin
            result["proxyPassword"] = self.proxyPassword
        if self.cookies:
            result["cookies"] = self.cookies
        return result


class RecaptchaV2TaskProxyless(BaseTask):
    type = "RecaptchaV2TaskProxyless"
    websiteURL = None
    websiteKey = None
    websiteSToken = None
    recaptchaDataSValue = None
    time_sleep=3
    def __init__(
        self,
        website_url,
        website_key,
        website_s_token=None,
        is_invisible=None,
        recaptcha_data_s_value=None,
    ):
        self.websiteURL = website_url
        self.websiteKey = website_key
        self.websiteSToken = website_s_token
        self.recaptchaDataSValue = recaptcha_data_s_value
        self.isInvisible = is_invisible

    def serialize(self):
        data = {
            "type": self.type,
            "websiteURL": self.websiteURL,
            "websiteKey": self.websiteKey,
        }
        if self.websiteSToken is not None:
            data["websiteSToken"] = self.websiteSToken
        if self.isInvisible is not None:
            data["isInvisible"] = self.isInvisible
        if self.recaptchaDataSValue is not None:
            data["recaptchaDataSValue"] = self.recaptchaDataSValue
        return data

class RecaptchaV2Task(BaseTask):
    type = "RecaptchaV2Task"
    websiteURL = None
    websiteKey = None
    websiteSToken = None
    recaptchaDataSValue = None
    time_sleep=3

    def __init__(
        self,
        website_url,
        website_key,proxy_address,proxy_port,proxy_type,user_agent,proxy_login=None,proxy_password=None,cookies=None,
        website_s_token=None,
        is_invisible=None,
        recaptcha_data_s_value=None):
        self.websiteURL = website_url
        self.websiteKey = website_key
        self.websiteSToken = website_s_token
        self.recaptchaDataSValue = recaptcha_data_s_value
        self.isInvisible = is_invisible
        self.proxyType = proxy_type
        self.userAgent = user_agent
        self.proxyAddress = proxy_address
        self.proxyPort = proxy_port
        self.proxyLogin = proxy_login
        self.proxyPassword = proxy_password
        self.cookies = cookies

    def serialize(self):
        data = {
            "type": self.type,
            "websiteURL": self.websiteURL,
            "websiteKey": self.websiteKey,
            "proxyType": self.proxyType,
            "proxyAddress": self.proxyAddress,
            "proxyPort": self.proxyPort,
            "userAgent": self.userAgent
        }
        if self.websiteSToken is not None:
            data["websiteSToken"] = self.websiteSToken
        if self.isInvisible is not None:
            data["isInvisible"] = self.isInvisible
        if self.recaptchaDataSValue is not None:
            data["recaptchaDataSValue"] = self.recaptchaDataSValue
        if self.proxyLogin is not None:
            data["proxyLogin"]= self.proxyLogin
        if self.proxyPassword is not None:
            data["proxyPassword"]= self.proxyPassword
        if self.cookies is not None:
            data["cookies"]= self.cookies
        return data





class FunCaptchaProxylessTask(BaseTask):
    type = "FunCaptchaTaskProxyless"
    websiteURL = None
    websiteKey = None
    time_sleep = 0.1
    def __init__(self, website_url, website_key, *args, **kwargs):
        self.websiteURL = website_url
        self.websiteKey = website_key
        super(FunCaptchaProxylessTask, self).__init__(*args, **kwargs)

    def serialize(self, **result):
        result = super(FunCaptchaProxylessTask, self).serialize(**result)
        result.update(
            {
                "type": self.type,
                "websiteURL": self.websiteURL,
                "websitePublicKey": self.websiteKey,
            }
        )
        return result



class ImageToTextTask(object):
    type = "ImageToTextTask"
    fp = None
    phrase = None
    case = None
    numeric = None
    math = None
    minLength = None
    maxLength = None
    time_sleep = 1
    def __init__(
        self,
        fp,
        phrase=None,
        case=None,
        numeric=None,
        math=None,
        min_length=None,
        max_length=None,
    ):
        self.fp = fp
        self.phrase = phrase
        self.case = case
        self.numeric = numeric
        self.math = math
        self.minLength = min_length
        self.maxLength = max_length

    def serialize(self):
        return {
            "type": self.type,
            "body": base64.b64encode(self.fp.read()).decode("utf-8"),
            "phrase": self.phrase,
            "case": self.case,
            "numeric": self.numeric,
            "math": self.math,
            "minLength": self.minLength,
            "maxLength": self.maxLength,
        }

class CustomCaptchaTask(BaseTask):
    type = "CustomCaptchaTask"
    imageUrl = None
    assignment = None
    form = None

    def __init__(self, imageUrl, form=None, assignment=None):
        self.imageUrl = imageUrl
        self.form = form or {}
        self.assignment = assignment

    def serialize(self):
        data = super(CustomCaptchaTask, self).serialize()
        data.update({"type": self.type, "imageUrl": self.imageUrl})
        if self.form:
            forms = []
            for name, field in self.form.items():
                if isinstance(field, BaseField):
                    forms.append(field.serialize(name))
                else:
                    field = field.copy()
                    field["name"] = name
                    forms.append(field)
            data["forms"] = forms
        if self.assignment:
            data["assignment"] = self.assignment
        return data


class RecaptchaV3TaskProxyless(BaseTask):
    type = "RecaptchaV3TaskProxyless"
    websiteURL = None
    websiteKey = None
    minScore = None
    pageAction = None
    time_sleep = 3
    def __init__(self, website_url, website_key, min_score, page_action=""):
        self.websiteURL = website_url
        self.websiteKey = website_key
        self.minScore = min_score
        self.pageAction = page_action

    def serialize(self):
        data = super(RecaptchaV3TaskProxyless, self).serialize()
        data["type"] = self.type
        data["websiteURL"] = self.websiteURL
        data["websiteKey"] = self.websiteKey
        data["minScore"] = self.minScore
        data["pageAction"] = self.pageAction
        return data


class HCaptchaTaskProxyless(BaseTask):
    type = "HCaptchaTaskProxyless"
    websiteURL = None
    websiteKey = None
    time_sleep = 2
    def __init__(self, website_url, website_key, *args, **kwargs):
        self.websiteURL = website_url
        self.websiteKey = website_key
        super(HCaptchaTaskProxyless, self).__init__(*args, **kwargs)

    def serialize(self, **result):
        data = super(HCaptchaTaskProxyless, self).serialize(**result)
        data["type"] = self.type
        data["websiteURL"] = self.websiteURL
        data["websiteKey"] = self.websiteKey
        return data

class HCaptchaTask(BaseTask):
    type = "HCaptchaTask"
    websiteURL = None
    websiteKey = None
    websiteSToken = None
    recaptchaDataSValue = None
    time_sleep = 2

    def __init__(
            self,
            website_url,
            website_key, proxy_address, proxy_port, proxy_type, user_agent, proxy_login=None, proxy_password=None):
        self.websiteURL = website_url
        self.websiteKey = website_key

        self.proxyType = proxy_type
        self.userAgent = user_agent
        self.proxyAddress = proxy_address
        self.proxyPort = proxy_port
        self.proxyLogin = proxy_login
        self.proxyPassword = proxy_password

    def serialize(self):
        data = {
            "type": self.type,
            "websiteURL": self.websiteURL,
            "websiteKey": self.websiteKey,
            "proxyType": self.proxyType,
            "proxyAddress": self.proxyAddress,
            "proxyPort": self.proxyPort,
            "userAgent": self.userAgent
        }
        if self.proxyLogin is not None:
            data["proxyLogin"] = self.proxyLogin
        if self.proxyPassword is not None:
            data["proxyPassword"] = self.proxyPassword
        return data

def captcha(url,site_key,apikey):
    client = AnycaptchaClient(apikey)
    is_invisible=True
    task = RecaptchaV2TaskProxyless(website_url=url, website_key=site_key,is_invisible=is_invisible)
    job = client.createTask(task)
    job.join()
    result=job.get_solution_response()
    if result.find("ERROR") != -1:
        print("fail ",result)
    else:
        return result